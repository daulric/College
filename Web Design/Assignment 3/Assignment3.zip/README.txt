This is all the design compiled into one webpage from Assignment 1

Hosted Website: https://assignment3-5j0.pages.dev/